# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Names:        Reed Scott (UIN: 838002005)
#               Sho Hiroi (UIN: 837008392)
#               Xavier Gomez (UIN: 538001968)
#               Izaac Almeida (UIN: 238008017)
# Section:      553
# Assignment:   Lab 9A
# Date:         October 27, 2026

def calculate_estimate(x1, y1, x2, y2, target_x):
    """Calculate the estimated y-value using a linear formula."""

    if x1 == x2:
        raise ValueError("Cannot calculate slope with identical x-values.")

    slope = (y2 - y1) / (x2 - x1)
    estimated_y = y1 + slope * (target_x - x1)

    return estimated_y


def estimate_value(x_values, y_values, target_x):
    """Determine the estimation type and calculate the result."""

    x1, y1, x2, y2, estimation_type = find_relevant_points(
        x_values, y_values, target_x
    )

    if estimation_type == "Exact Match":
        estimated_y = y1
    else:
        estimated_y = calculate_estimate(x1, y1, x2, y2, target_x)

    return estimated_y, estimation_type