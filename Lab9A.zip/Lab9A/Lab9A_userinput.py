# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Names:        Reed Scott (UIN: 838002005)
#               Sho Hiroi (UIN: 837008392)
#               Xavier Gomez (UIN: 538001968)
#               Izaac Almeida (UIN: 238008017)
# Section:      553
# Assignment:   Lab 9A
# Date:         October 27, 2026

def get_data_points():
    """Collect and validate the user's data points."""

    while True:
        try:
            num_points = int(input("How many data points do you want to enter? "))

            if num_points < 2:
                print("Please enter at least 2 data points.")
                continue

            break
        except ValueError:
            print("Invalid input. Enter a whole number.")

    x_values = []
    y_values = []

    for i in range(num_points):
        while True:
            try:
                x = float(input(f"Enter x-coordinate for point {i + 1}: "))
                y = float(input(f"Enter y-coordinate for point {i + 1}: "))

                if x in x_values:
                    print("Each x-coordinate must be unique. Try again.")
                    continue

                x_values.append(x)
                y_values.append(y)
                break

            except ValueError:
                print("Invalid input. Please enter numeric coordinates.")

    return x_values, y_values


def get_target_x():
    """Ask the user for the x-value to estimate."""

    while True:
        try:
            return float(input("Enter the x-value you want to estimate: "))
        except ValueError:
            print("Invalid input. Please enter a number.")