# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Names:        Reed Scott (UIN: 838002005)
#               Sho Hiroi (UIN: 837008392)
#               Xavier Gomez (UIN: 538001968)
#               Izaac Almeida (UIN: 238008017)
# Section:      553
# Assignment:   Lab 9A
# Date:         October 27, 2026

def sort_data_points(x_values, y_values):
    """Sort the points by x while keeping coordinate pairs together."""

    points = sorted(zip(x_values, y_values))
    x_values = [point[0] for point in points]
    y_values = [point[1] for point in points]

    return x_values, y_values


def find_relevant_points(x_values, y_values, target_x):
    """Find the two points needed for interpolation or extrapolation."""

    # Check for an exact match first
    for i in range(len(x_values)):
        if target_x == x_values[i]:
            return x_values[i], y_values[i], x_values[i], y_values[i], "Exact Match"

    # Find points surrounding the target
    for i in range(len(x_values) - 1):
        if x_values[i] < target_x < x_values[i + 1]:
            return (
                x_values[i], y_values[i],
                x_values[i + 1], y_values[i + 1],
                "Interpolation"
            )

    # Use the first two points for lower extrapolation
    if target_x < x_values[0]:
        return (
            x_values[0], y_values[0],
            x_values[1], y_values[1],
            "Extrapolation"
        )

    # Use the last two points for upper extrapolation
    return (
        x_values[-2], y_values[-2],
        x_values[-1], y_values[-1],
        "Extrapolation"
    )
