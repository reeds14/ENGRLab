# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Names:        Reed Scott (UIN: 838002005)
#               Sho Hiroi (UIN: 837008392)
#               Xavier Gomez (UIN: 538001968)
#               Izaac Almeida (UIN: 238008017)
# Section:      553
# Assignment:   Lab 9A
# Date:         October 27, 2026


def get_data_points():
    """Collect and validate the user's data points."""

    while True:
        try:
            num_points = int(input("How many data points do you want to enter? "))

            if num_points < 2:
                print("Please enter at least 2 data points.")
                continue

            break
        except ValueError:
            print("Invalid input. Enter a whole number.")

    x_values = []
    y_values = []

    for i in range(num_points):
        while True:
            try:
                x = float(input(f"Enter x-coordinate for point {i + 1}: "))
                y = float(input(f"Enter y-coordinate for point {i + 1}: "))

                if x in x_values:
                    print("Each x-coordinate must be unique. Try again.")
                    continue

                x_values.append(x)
                y_values.append(y)
                break

            except ValueError:
                print("Invalid input. Please enter numeric coordinates.")

    return x_values, y_values


def get_target_x():
    """Ask the user for the x-value to estimate."""

    while True:
        try:
            return float(input("Enter the x-value you want to estimate: "))
        except ValueError:
            print("Invalid input. Please enter a number.")

def sort_data_points(x_values, y_values):
    """Sort the points by x while keeping coordinate pairs together."""

    points = sorted(zip(x_values, y_values))
    x_values = [point[0] for point in points]
    y_values = [point[1] for point in points]

    return x_values, y_values


def find_relevant_points(x_values, y_values, target_x):
    """Find the two points needed for interpolation or extrapolation."""

    # Check for an exact match first
    for i in range(len(x_values)):
        if target_x == x_values[i]:
            return x_values[i], y_values[i], x_values[i], y_values[i], "Exact Match"

    # Find points surrounding the target
    for i in range(len(x_values) - 1):
        if x_values[i] < target_x < x_values[i + 1]:
            return (
                x_values[i], y_values[i],
                x_values[i + 1], y_values[i + 1],
                "Interpolation"
            )

    # Use the first two points for lower extrapolation
    if target_x < x_values[0]:
        return (
            x_values[0], y_values[0],
            x_values[1], y_values[1],
            "Extrapolation"
        )

    # Use the last two points for upper extrapolation
    return (
        x_values[-2], y_values[-2],
        x_values[-1], y_values[-1],
        "Extrapolation"
    )


def calculate_estimate(x1, y1, x2, y2, target_x):
    """Calculate the estimated y-value using a linear formula."""

    if x1 == x2:
        raise ValueError("Cannot calculate slope with identical x-values.")

    slope = (y2 - y1) / (x2 - x1)
    estimated_y = y1 + slope * (target_x - x1)

    return estimated_y


def estimate_value(x_values, y_values, target_x):
    """Determine the estimation type and calculate the result."""

    x1, y1, x2, y2, estimation_type = find_relevant_points(
        x_values, y_values, target_x
    )

    if estimation_type == "Exact Match":
        estimated_y = y1
    else:
        estimated_y = calculate_estimate(x1, y1, x2, y2, target_x)

    return estimated_y, estimation_type



def display_result(target_x, estimated_y, estimation_type):
    """Display the target x-value, estimated y-value, and method."""

    print("\n----- Estimation Result -----")
    print(f"Target x-value: {target_x}")
    print(f"Estimated y-value: {estimated_y}")
    print(f"Method used: {estimation_type}")
    print("-----------------------------\n")


def main():
    """Run the program and allow repeated estimations."""

    print("Linear Interpolation and Extrapolation Program")
    print("Enter your data points below.\n")

    x_values, y_values = get_data_points()
    x_values, y_values = sort_data_points(x_values, y_values)

    continue_program = "yes"

    while continue_program.lower() in ("yes", "y"):
        target_x = get_target_x()

        try:
            estimated_y, estimation_type = estimate_value(
                x_values, y_values, target_x
            )

            display_result(target_x, estimated_y, estimation_type)

        except ValueError as error:
            print(f"Calculation error: {error}")

        continue_program = input(
            "Would you like to estimate another value? (yes/no): "
        ).strip()

    print("Program ended. Thank you!")


# Start the program
if __name__ == "__main__":
    main()
