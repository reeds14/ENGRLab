# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do."
# "I have not given or received any unauthorized aid on this assignment."
#
# Names:        Reed Scott (UIN: 838002005)
#               Sho Hiroi (UIN: 837008392)
#               Xavier Gomez (UIN: 538001968)
#               Izaac Almeida (UIN: 238008017)
# Section:      553
# Assignment:   Lab 9A
# Date:         October 27, 2026

def display_result(target_x, estimated_y, estimation_type):
    """Display the target x-value, estimated y-value, and method."""

    print("\n----- Estimation Result -----")
    print(f"Target x-value: {target_x}")
    print(f"Estimated y-value: {estimated_y}")
    print(f"Method used: {estimation_type}")
    print("-----------------------------\n")


def main():
    """Run the program and allow repeated estimations."""

    print("Linear Interpolation and Extrapolation Program")
    print("Enter your data points below.\n")

    x_values, y_values = get_data_points()
    x_values, y_values = sort_data_points(x_values, y_values)

    continue_program = "yes"

    while continue_program.lower() in ("yes", "y"):
        target_x = get_target_x()

        try:
            estimated_y, estimation_type = estimate_value(
                x_values, y_values, target_x
            )

            display_result(target_x, estimated_y, estimation_type)

        except ValueError as error:
            print(f"Calculation error: {error}")

        continue_program = input(
            "Would you like to estimate another value? (yes/no): "
        ).strip()

    print("Program ended. Thank you!")


# Start the program
if __name__ == "__main__":
    main()